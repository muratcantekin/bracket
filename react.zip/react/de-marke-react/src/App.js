import React, { useState, setState } from "react";
import "./App.css";



function Group() {
//statik olarak basılmış turnuva grupları
  const grupA = [
    {
      name: 'SENEGAL🇸🇳'
    },
    {
      name: 'EKVADOR🇪🇨'
    },
    {
      name: 'HOLLANDA🇳🇱'
    },
    {
      name: 'KATAR🇶🇦'
    }
  ]
  const grupB = [
    {
      name: 'ABD🇺🇸'
    },
    {
      name: 'İNGİLTERE🏴󠁧󠁢󠁥󠁮󠁧󠁿'
    },
    {
      name: 'İRAN🇮🇷'
    },
    {
      name: 'GALLER🏴󠁧󠁢󠁷󠁬󠁳󠁿'
    }
  ]
  const grupC = [
    {
      name: 'ARJANTİN🇦🇷'
    },
    {
      name: 'POLONYA🇵🇱'
    },
    {
      name: 'MEKSİKA🇲🇽'
    },
    {
      name: 'S.ARABİSTAN🇸🇦'
    }
  ]
  const grupD = [
    {
      name: 'TUNUS🇹🇳'
    },
    {
      name: 'FRANSA🇫🇷'
    },
    {
      name: 'DANİMARKA🇩🇰'
    },
    {
      name: 'AVUSTRALYA🇦🇺'
    }
  ]
  const grupE = [
    {
      name: 'İSPANYA🇪🇸'
    },
    {
      name: 'JAPONYA🇯🇵'
    },
    {
      name: 'ALMANYA🇩🇪'
    },
    {
      name: 'KOSTA RİKA🇨🇷'
    }
  ]
  const grupF = [
    {
      name: 'FAS🇲🇦'
    },
    {
      name: 'BELÇİKA🇧🇪'
    },
    {
      name: 'KANADA🇨🇦'
    },
    {
      name: 'HIRVATİSTAN🇭🇷'
    }
  ]
  const grupG = [
    {
      name: 'İSVİÇRE🇨🇭'
    },
    {
      name: 'BREZİLYA🇧🇷'
    },
    {
      name: 'KAMERUN🇨🇲'
    },
    {
      name: 'SIRBİSTAN🇷🇸'
    }
  ]
  const grupH = [
    {
      name: 'GANA🇬🇭'
    },
    {
      name: 'G.KORE🇿🇦'
    },
    {
      name: 'PORTEKİZ🇵🇹'
    },
    {
      name: 'URUGUAY🇺🇾'
    }
  ]

  // 8 gruptan 2şer takım çıkacak bu da 16 takım ve 8 eşleşme ediyor, dinamik olarak tutabilmek ve karıştırmamak için 8 farklı qualifier array ı oluşturdum.
  const [qualifier1, setQualifier1] = useState([{ name: '' }, { name: '' }]);
  const [qualifier2, setQualifier2] = useState([{ name: '' }, { name: '' }]);
  const [qualifier3, setQualifier3] = useState([{ name: '' }, { name: '' }]);
  const [qualifier4, setQualifier4] = useState([{ name: '' }, { name: '' }]);
  const [qualifier5, setQualifier5] = useState([{ name: '' }, { name: '' }]);
  const [qualifier6, setQualifier6] = useState([{ name: '' }, { name: '' }]);
  const [qualifier7, setQualifier7] = useState([{ name: '' }, { name: '' }]);
  const [qualifier8, setQualifier8] = useState([{ name: '' }, { name: '' }]);

  //burda yukarıda analttığım olayın benzerini 4 çeyrek final eşleşmesi için yaptım.
  const [quarter1, setQuarter1] = useState([{ name: '' }, { name: '' }])
  const [quarter2, setQuarter2] = useState([{ name: '' }, { name: '' }])
  const [quarter3, setQuarter3] = useState([{ name: '' }, { name: '' }])
  const [quarter4, setQuarter4] = useState([{ name: '' }, { name: '' }])

  //bu da 2 yarı final eşleşmesi için
  const [semi1, setSemi1] = useState([{ name: '' }, { name: '' }])
  const [semi2, setSemi2] = useState([{ name: '' }, { name: '' }])

  //final eşleşmesi için dinamik array
  const [final, setFinal] = useState([{ name: '' }, { name: '' }])

  //bu fonksiyon ile grup isimleri kontrol ediliyor ona göre de takımları doğru çapraz eşleşmelere yönlendirebiliyor. grup birincisi olarak tıklanan takım yanındaki eşleşmenin ilk elementi oluyor, 2. elementi de bir alt eşleşmenin 1. elementi oluyor.
  function moveText(groupName, teamName) {
    var temp = teamName;
    if (groupName === 'grupA') 
    {
      if (qualifier1[0].name === '') 
      {
        qualifier1[0].name = temp;
        setQualifier1([...qualifier1])
      } 
      else 
      {
        qualifier2[1].name = temp;
        setQualifier2([...qualifier2]);
      }
    } 
      else if (groupName === 'grupB') 
    {
      if (qualifier2[0].name === '') 
      {
        qualifier2[0].name = temp;
        setQualifier2([...qualifier2]);
      }
      else 
      {
        qualifier1[1].name = teamName;
        setQualifier1([...qualifier1])
      }
    }
    else if (groupName === 'grupC') 
    {
      if (qualifier3[0].name === '') 
      {
        qualifier3[0].name = temp;
        setQualifier3([...qualifier3])
      } else {
        qualifier4[1].name = temp;
        setQualifier4([...qualifier4])
      }
    }
    else if (groupName === 'grupD') 
    {
      if (qualifier4[0].name === '') 
      {
        qualifier4[0].name = temp;
        setQualifier4([...qualifier4])
      }
      else 
      {
        qualifier3[1].name = temp;
        setQualifier3([...qualifier3])
      }
    }
    else if (groupName === 'grupE') 
    {
      if (qualifier5[0].name === '') 
      {
        qualifier5[0].name = temp;
        setQualifier5([...qualifier5])
      } else 
      {
        qualifier6[1].name = temp;
        setQualifier6([...qualifier6])
      }
    }
    else if (groupName === 'grupF') 
    {
      if (qualifier6[0].name === '') 
      {
        qualifier6[0].name = temp;
        setQualifier6([...qualifier6])
      }
      else 
      {
        qualifier5[1].name = temp;
        setQualifier5([...qualifier5])
      }
    }
    else if (groupName === 'grupG') 
    {
      if (qualifier7[0].name === '') 
      {
        qualifier7[0].name = temp;
        setQualifier7([...qualifier7])
      } 
      else 
      {
        qualifier8[1].name = temp;
        setQualifier8([...qualifier8])
      }
    }
    else if (groupName === 'grupH') 
    {
      if (qualifier8[0].name === '') 
      {
        qualifier8[0].name = temp;
        setQualifier8([...qualifier8])      
      }
      else 
      {
        qualifier7[1].name = temp;
        setQualifier7([...qualifier7])      
      }
    }
    return;
  }

//moveQ1, moveQ2, moveQ3, moveQ4 tamamen aynı mantıkla çalışan 4 fonksiyon ve sırasıyla 1den 4e kadarki quarter1,2,3,4 array lerini dinamik olarak doldurmak için kullanılıyor.
  function moveQ1(teamName) {
    var tempQuarter1 = teamName;
    if (quarter1[0].name === '')
    {
      quarter1[0].name = tempQuarter1;
      setQuarter1([...quarter1])
    }
   else if(quarter1[1].name === '')
    {
      quarter1[1].name = tempQuarter1;
      setQuarter1([...quarter1])
    }
    return;
    }

  function moveQ2(teamName) {
    var tempQuarter2 = teamName;
    if (quarter2[0].name === '')
     {
      quarter2[0].name = tempQuarter2;
      setQuarter2([...quarter2])
     }
   else if(quarter2[1].name === '')
    {
      quarter2[1].name = tempQuarter2;
      setQuarter2([...quarter2])
    }
    return;
    }

  function moveQ3(teamName) {
    debugger;
    var tempQuarter3 = teamName;
    if (quarter3[0].name === '')
     {
      quarter3[0].name = tempQuarter3;
      setQuarter3([...quarter3])
     }
   else if(quarter3[1].name === '')
    {
      quarter3[1].name = tempQuarter3;
      setQuarter3([...quarter3])
    }
    return;
    }

  function moveQ4(teamName) {
    debugger;
    var tempQuarter4 = teamName;
    if (quarter4[0].name === '')
     {
      quarter4[0].name = tempQuarter4;
      setQuarter4([...quarter4])
     }
   else if(quarter4[1].name === '')
    {
      quarter4[1].name = tempQuarter4;
      setQuarter4([...quarter4])
    }
    return;
    }

    function removeQualifiers(teamName){
      if (qualifier1[0].name != '')
      {
        qualifier1[0].name = '';
        setQualifier1([...qualifier1])
      }
      else if (qualifier1[1].name != '') 
      {
        qualifier1[1].name = '';
        setQualifier1([...qualifier1])
      }
      }


//moveS1 ve S2 moveQ1,2,3,4 le aynı mantıkla çalışan fonksiyon ve tek farkı yarı final eşleşmelerini dolduruyor olması.
  function moveS1(teamName) {
    debugger;
    var tempSemi1 = teamName;
    if (semi1[0].name === '')
     {
      semi1[0].name = tempSemi1;
      setSemi1([...semi1])
     }
   else if(semi1[1].name === '')
    {
      semi1[1].name = tempSemi1;
      setSemi1([...semi1])
    }
    return;
    }

  function moveS2(teamName) {
    debugger;
    var tempSemi2 = teamName;
    if (semi2[0].name === '')
     {
      semi2[0].name = tempSemi2;
      setSemi2([...semi2])
     }
   else if(semi2[1].name === ''){
      semi2[1].name = tempSemi2;
      setSemi2([...semi2])
  }
    return;
  
  }

//final fonksiyonu da moveS1 ve S2 ile aynı mantıkla çalışıyor.
  function moveF1(teamName) {
    debugger;
    var tempFinal1 = teamName;
    if (final[0].name === '')
     {
      final[0].name = tempFinal1;
      setFinal([...final])
     }
   else if(final[1].name === '')
    {
      final[1].name = tempFinal1;
      setFinal([...final])
    }
    return;
  }

/*      <li class="ft-stwitter">
      <a rel="nofollow" target="_blank" href="https://twitter.com/intent/tweet?url=http://www.mywebebsite.com/the-url/&amp;text=Blog Title">
        <i class="icon-twitter"></i> Share on Twitter
      </a>
  </li>*/

  //yukarıdaki comment sayesinde share on twitter için ikon çıkartılabiliyor, kodu yazıldığında bitiş pop-up'ında kullanılabilir.
  return (

    <div id="root">
      <img src="images\arka-plan.png" alt="images" className="bgimages"></img>

      <div className="Group_Left">
        <div className="grupA" id="g">
          <h5>
          </h5>
          <div id="ge">
            {grupA.map((object, i) =>
              <button type="button" onClick={() => moveText('grupA', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
        <div className="grupB" id="g">
          <h5></h5>
          <div id="ge">
            {grupB.map((object, i) =>
              <button type="button" onClick={() => moveText('grupB', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
        <div className="grupC" id="g">
          <h5></h5>
          <div id="ge">
            {grupC.map((object, i) =>
              <button type="button" onClick={() => moveText('grupC', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
        <div className="grupD" id="g">
          <h5></h5>
          <div id="ge">
            {grupD.map((object, i) =>
              <button type="button" onClick={() => moveText('grupD', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Son 16 */}

      <div className="Last16L" id="l16">
        <div className="last16divL">

          <div className="qualifier1" >
          {qualifier1.map((object, i) =>
              <button type="button" onClick={() => moveQ1(object.name)} onDoubleClick={() => removeQualifiers(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier2">
          {qualifier2.map((object, i) =>
              <button type="button" onClick={() => moveQ1(object.name)}  className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier3">
          {qualifier3.map((object, i) =>
              <button type="button" onClick={() => moveQ2(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier4">
          {qualifier4.map((object, i) =>
              <button type="button" onClick={() => moveQ2(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
        </div>
      </div>

      {/* Çeyrek Final */}

      <div className="Quarter_Final_Left" id="q">
        <div className="quarter1">
        {quarter1.map((object, i) =>
              <button type="button" onClick={() => moveS1(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
        </div>
        <div className="QFtwins2">
        {quarter2.map((object, i) =>
              <button type="button" onClick={() => moveS1(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
        </div>
      </div>

      {/* Yarı Final */}

      <div className="Semi_Final_Left" id="s">
        <div className="SFtwins">
        {semi1.map((object, i) =>
              <button type="button" onClick={() => moveF1(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
      </div>

      {/* Final */}
        {/*Burda onclick ile pop-up ekranının açılıp şampiyon takımın adı ve bayrak emojisi çıkmalı altında da twitter'da paylaş butonu olması gerekiyor. */}
      <div className="Final" id="f">
        <h1>Final</h1>
        <div className="Finalh">
        {final.map((object, i) =>
              <button type="button" onClick className="hexagon" >
                {object.name}
              </button>
          )}
        </div>
      </div>
      {/* Yarı Final  Sağ */}

      <div className="Semi_FinalR" id="s">
        <div className="SFtwinsR">
        {semi2.map((object, i) =>
              <button type="button" onClick={() => moveF1(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
        </div>
      </div>

      {/* Çeyrek Final Sağ */}

      <div className="Quarter_Final_Right" id="q">
        <div className="QFtwins1R">
        {quarter3.map((object, i) =>
              <button type="button" onClick={() => moveS2(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
        </div>
        <div className="QFtwins2R">
        {quarter4.map((object, i) =>
              <button type="button" onClick={() => moveS2(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
        </div>
      </div>

      {/* Son 16 */}

      <div className="Last-16R" id="l16">
        <div className="last16divR">
          <div className="qualifier5" >
          {qualifier5.map((object, i) =>
              <button type="button" onClick={() => moveQ3(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier6">
          {qualifier6.map((object, i) =>
              <button type="button" onClick={() => moveQ3(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier7">
          {qualifier7.map((object, i) =>
              <button type="button" onClick={() => moveQ4(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
          <div className="qualifier8">
          {qualifier8.map((object, i) =>
              <button type="button" onClick={() => moveQ4(object.name)} className="hexagon">
                {object.name}
              </button>
          )}
          </div>
        </div>
      </div>

      <div className="Group_Right">
        <div className="grupE" id="g">
          <h5></h5>
          <div id="ge">
            {grupE.map((object, i) =>
              <button type="button" onClick={() => moveText('grupE', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
        <div className="grupF" id="g">
          <h5></h5>
          <div id="ge">
            {grupF.map((object, i) =>
              <button type="button" onClick={() => moveText('grupF', object.name)} className="hexagon">
                {object.name}
              </button>
            )}
          </div>
        </div>
        <div className="grupG" id="g">
          <h5></h5>
          <div id="ge">
            {grupG.map((object, i) =>
              <button type="button" onClick={() => moveText('grupG', object.name)} className="hexagon">
                {object.name}
              </button>
            )}

          </div>
        </div>
        <div className="grupH" id="g">
          <h5></h5>
          <div id="ge">
            {grupH.map((object, i) =>
              <button type="button" onClick={() => moveText('grupH', object.name)} className="hexagon">
                {object.name}
              </button>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
export default Group;
